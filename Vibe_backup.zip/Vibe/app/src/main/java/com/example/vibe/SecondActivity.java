package com.example.vibe;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.*;
import android.content.*;
import android.os.Bundle;

public class SecondActivity extends AppCompatActivity {

    Button returnHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        returnHome = (Button)findViewById(R.id.returnHome);
        TextView text = (TextView)findViewById(R.id.hello);
        text.setText("Hello World");

        returnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}